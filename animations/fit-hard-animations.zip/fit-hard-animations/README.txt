Fit Hard exercise animations, organised.

exercises/<exercise>/<avatar>/pose-1.webp, pose-2.webp, pose-3.webp
  avatar = default (all people), girl, boy, nonbinary
  The app shows the person's chosen avatar when that folder exists, otherwise default.
machines/<machine>/pose-1..3.webp
index.json lists which avatars exist for each exercise.
App file names: anim-<exercise>-N.webp (default), anim-girl|boy|nb-<exercise>-N.webp.
